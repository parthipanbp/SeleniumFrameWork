package com.encora.smokeSuiteTests;


import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
import com.encora.pages.InventoryPage;
import com.encora.pages.LoginPage;
import com.encora.reusableMethods.WebPageOperations;
import com.encora.tests.BaseTest;
import com.encora.utilities.ConfigFileReader;
import com.encora.utilities.ExcelUtility;



public class VerifyUserLogin extends BaseTest {
	
	public WebDriver driver;
	LoginPage loginPage;
	InventoryPage inventoryPage;
	ExcelUtility excelUtility;
	ConfigFileReader configFileReader;

	@Test(priority = 1, description = "Verify that user is able to login to SwagsLabs application")
	public void logIntoSwagsLabs() {
		driver = getDriver();
		configFileReader = new ConfigFileReader();
		configFileReader.loadPropertiesFile("login");
		excelUtility = new ExcelUtility(System.getProperty("excelFileName"), System.getProperty("excelLoginSheetName"));
		loginPage = new LoginPage(driver);
		assertEquals(loginPage.getPageTitle(), System.getProperty("pageTitle"), "page title mismatch");
		assertTrue(loginPage.headingIsDisplayed("SwagsLabs heading"), "SwagsLabs heading is not displayed");
		assertTrue(loginPage.botImageIsDisplayed("bot image"), "Bot Image is not displayed");
		loginPage.getUserNames("default user names");
		loginPage.getPassword("default password");
		WebPageOperations.waitForSeconds(1);
		loginPage.login(excelUtility.getCellData(1, 0), excelUtility.getCellData(1, 1));
		//loginPage.login(System.getProperty("userName"), System.getProperty("password"));
		configFileReader.loadPropertiesFile("inventory");
		inventoryPage = new InventoryPage(driver);
		assertEquals(inventoryPage.getPageURL(), System.getProperty("inventoryPageURL"), "User is not redirected to inventory page");
		WebPageOperations.waitForSeconds(2);
		
		
		
		
	}

	
}
