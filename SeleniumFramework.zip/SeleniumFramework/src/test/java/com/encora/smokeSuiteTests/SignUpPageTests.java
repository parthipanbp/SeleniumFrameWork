package com.encora.smokeSuiteTests;

public class SignUpPageTests {

}
