package com.encora.smokeSuiteTests;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.encora.pages.CartPage;
import com.encora.pages.InventoryPage;
import com.encora.pages.LoginPage;
import com.encora.reusableMethods.WebPageOperations;
import com.encora.tests.BaseTest;
import com.encora.utilities.ConfigFileReader;
import com.encora.utilities.ExcelUtility;

public class AddProductToCart extends BaseTest {
	
	public WebDriver driver;
	LoginPage loginPage;
	InventoryPage inventoryPage;
	CartPage cartPage;
	ExcelUtility excelUtility;
	ConfigFileReader configFileReader;
	
	@Test(priority = 1, description = "Verify that user is able to login to SwagsLabs application")
	public void logIntoSwagsLabs() {
		driver = getDriver();
		loginPage = new LoginPage(driver);
		 configFileReader = new ConfigFileReader();
		configFileReader.loadPropertiesFile("login");
		excelUtility = new ExcelUtility(System.getProperty("excelFileName"), System.getProperty("excelLoginSheetName"));
		loginPage.login(excelUtility.getCellData(1, 0), excelUtility.getCellData(1, 1));

	}
	
	@Test(priority = 2, description = "Verify inventory page fields", dependsOnMethods = {"logIntoSwagsLabs"})
	public void verifyInventoryPageElements() {
		
		inventoryPage =  new InventoryPage(driver);
		assertTrue(inventoryPage.menuIconIsDisplayed(), "menu icon is not identified");
		assertTrue(inventoryPage.productsHeadingIsDisplayed(), "products heading is not displayed");
		assertTrue(inventoryPage.robotIconIsDisplayed(), "bot icon is not identified on inventory page");
		assertTrue(inventoryPage.shoppingCartLinkIsDisplayed(), "not able to recognise cart icon on screen");
		
		
	}

	@Test(priority = 3, description = " add products to cart",dependsOnMethods = {"logIntoSwagsLabs"})
	public void addProductsToCart() {
		configFileReader.loadPropertiesFile("inventory");
		inventoryPage.applyLowToHighFilter(System.getProperty("priceFilterValue"));
		inventoryPage.addProductsToCart(driver);
		

	}
	
	@Test(priority = 3, description = "verify cart size", dependsOnMethods = {"addProductsToCart"})
	public void verifyCartSize() {
		assertNotNull(inventoryPage.getCartAddedItemsCount(), "cart value is zero/null or not available");
		assertEquals(inventoryPage.getTotalProductsCount(), inventoryPage.getCartAddedItemsCount(), "added products and cart value is not matched");
		WebPageOperations.waitForSeconds(5);
		
	}
	@Test(priority = 3, description = "verify that products added to cart are displayed inside cart", dependsOnMethods = {"addProductsToCart"})
	public void verifyItemsAddedToCart() {
		List<String> productsNames = inventoryPage.getProductsNames();
		inventoryPage.clickOnShoppingCart();
		cartPage = new CartPage(driver);
		assertEquals(productsNames, cartPage.getCartAddedItemsNames(), "Added Items names are not matching in the cart");
		WebPageOperations.waitForSeconds(4);
		cartPage.clickOnContinueShopping();
		
	}
	
	@Test(priority = 4, description = "verify that user is able to logout from SwagLabs application", dependsOnMethods = {"verifyItemsAddedToCart"})
	public void logout() {
		inventoryPage.clickOnMenuIcon();
		WebPageOperations.waitForSeconds(1);
		inventoryPage.clickOnLogoutLink();
		WebPageOperations.waitForSeconds(1);
		WebPageOperations.waitForSeconds(2);
		configFileReader.loadPropertiesFile("login");
		assertEquals(loginPage.getPageURL(), System.getProperty("SauceDemoURL"));
	}

}
