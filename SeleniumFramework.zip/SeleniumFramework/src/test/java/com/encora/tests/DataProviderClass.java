package com.encora.tests;
//package com.veracross.magnus.tests;
//
//import org.testng.annotations.DataProvider;
//
//
//import com.veracross.magnus.utilities.ExcelUtility;
//
//public class DataProviderClass {
//	
//	 ExcelUtility excelUtility;
//	static int totalRows;
//	
//	
//	public String path = System.getProperty("user.dir") + "\\src\\test\\resources\\testData.xlsx";
//	
//	@DataProvider(name = "LoginCredentials Provider")
//	public  String[][] getData(){
//		String loginData[][] = null;
//		excelUtility = new ExcelUtility(path);
//		try {
//
//			totalRows = excelUtility.getTotalNumberOfRows("LoginTestData");
//			System.out.println(totalRows);
//			int totalColumns = excelUtility.getTotalNumberOfColumns("LoginTestData", 1);
//			System.out.println(totalColumns);
//			loginData = new String[totalRows][totalColumns];
//
//			for (int i = 1; i <= totalRows; i++) // 1
//			{
//				
//					for (int j = 0; j < totalColumns; j++) // 0
//					{
//
//						loginData[i - 1][j] = excelUtility.getCellData("LoginTestData", i, j);
//					}
//					// newLoginData = cloneArray(loginData);
//
//				}
//
//		} catch (Exception e) {
//			// TODO: handle exception
//		}
//		return loginData;
//		
//
//		
//	}
//
//}
