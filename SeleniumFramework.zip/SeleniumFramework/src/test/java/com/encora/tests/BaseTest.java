package com.encora.tests;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterClass;

import com.encora.logs.*;
import com.encora.reusableMethods.WebPageOperations;
import com.encora.utilities.AppConfig;
import com.encora.utilities.ConfigFileReader;
import com.encora.utilities.DriverFactory;

import org.testng.annotations.BeforeClass;



public class BaseTest {

	ConfigFileReader configFileReader;	
    private WebDriver driver;


	@BeforeClass(alwaysRun = true)
	public void browserSetUp() throws Exception {
		browserInitialization();
}
		

	@AfterClass(alwaysRun = true)
	public void tearDown() throws Exception {
		driver.manage().deleteAllCookies();
		driver.quit();
		Thread.sleep(5000);
		Log.info("driver successfully closed");
	}
	
	public WebDriver getDriver() {
		return driver;
	}

	public WebDriver browserInitialization() throws Exception {
		DriverFactory driverFactory = new DriverFactory();
		driver = driverFactory.lauchBrowser();
		WebPageOperations.waitForSeconds(2);
		 configFileReader = new ConfigFileReader();
		 configFileReader.loadPropertiesFile("Configuration");
		int implicitWaitTime = configFileReader.getImplicitWait();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(implicitWaitTime));
		System.out.println("Implicit wait time of " + implicitWaitTime
				+ " seconds is added so that every element will have maximum implicit waittime of " + implicitWaitTime
				+ " seconds before selenium throwing not located error");
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(configFileReader.getPageLoadWaitTime()));
		driver.manage().window().maximize();
		Log.info("Navigate to application Login URL");
		driver.get(getApplicationURL());
		return driver;

	}

	public WebDriver getTargetDriver() {
		if (driver == null) {
			String message = "Driver is null, cannot continue. Application has probably crashed or Driver creation failed!";
			System.out.println(message);
		}
		PageFactory.initElements(driver, this);
		return driver;
	}
	
	public String getApplicationURL() throws Exception {
		String environment = AppConfig.environment.toUpperCase();
		String URL=null;
		switch (environment) {
		case "DEV" : {
			
			URL = System.getProperty(environment.toLowerCase() + ".baseURI");
			System.out.println("URL loaded "+ URL );
			break;
		}
		
		case "QA" : {
			URL = System.getProperty(environment.toLowerCase() + ".baseURI");
			System.out.println("URL loaded "+ URL );
			break;
		}
		
		case "UAT" : {
			URL = System.getProperty(environment.toLowerCase() + ".baseURI");
			System.out.println("URL loaded "+ URL );
			break;
		}
		
		case "PROD" : {
			System.out.println(environment.toLowerCase() + ".baseURI");
			URL = System.getProperty(environment.toLowerCase() + ".baseURI");
			System.out.println("URL loaded "+ URL );
			break;
		}
			
		default:
			throw new Exception("Incorrect environment variable passed. Please use dev or qa or uat or prod as environment value");
	}
		
		return URL;
		

}
}
