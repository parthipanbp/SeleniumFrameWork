package com.encora.tests;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class GlobalData {
	
	public File file;
	private XSSFWorkbook excelWBook; // Excel WorkBook
	public XSSFSheet excelWorkSheet;
	public  FileInputStream excelFile;
	
	public void setFile(String fileName) throws IOException
	  {
	    ClassLoader classLoader = getClass().getClassLoader();
	    System.out.println(classLoader);
	        URL resource = classLoader.getResource(fileName);
	        System.out.println(resource);
	        if (resource == null) {
	            throw new IllegalArgumentException("file is not found!");
	        } 
	        System.out.println(resource.getFile());
	        file  = new File(resource.getFile());
	        System.out.println(file);
	  }
	
	public GlobalData(String fileName, String sheetName) {
		try {
			setFile(fileName);
			excelFile = new FileInputStream(file);
			excelWBook = new XSSFWorkbook(excelFile);
			excelWorkSheet = excelWBook.getSheet(sheetName);
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
		
	}
	public void getData() {
		
		XSSFCell cell = excelWorkSheet.getRow(1).getCell(1);
		String value = new DataFormatter().formatCellValue(cell);
		System.out.println(value);
	}
	
	public static void main(String[] args) {
		
		GlobalData globalData = new GlobalData("TestData.xlsx", "LoginTestData");
		globalData.getData();
		
	}
	}
	

