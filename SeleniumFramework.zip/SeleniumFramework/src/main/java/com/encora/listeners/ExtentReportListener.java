package com.encora.listeners;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.encora.extentreports.ExtentManager;
import com.encora.extentreports.ExtentTestManager;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;
import org.testng.Reporter;

import static com.encora.extentreports.ExtentManager.OUTPUT_FOLDER_SCREENSHOTS;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ExtentReportListener  implements ITestListener {

	
	
public  WebDriver driver;

	

	private static long endTime;

	private static void setStartTime(long startTime) {
	}

	private static void setEndTime(long endTime) {
		ExtentReportListener.endTime = endTime;
	}

	@Override
	public synchronized void onStart(ITestContext context) {
	}

	@Override
	public synchronized void onFinish(ITestContext context) {
		setStartTime(context.getStartDate().getTime());
		setEndTime(context.getEndDate().getTime());
	}

	@Override
	public synchronized void onTestStart(ITestResult result) {
		System.out.println("--------- Executing :- " + getSimpleMethodName(result) + " ---------");
		ExtentTestManager.createTest(result.getName(), result.getMethod().getDescription());
		ExtentTestManager.setCategoryName(getSimpleClassName(result));
	}

	@Override
	public synchronized void onTestSuccess(ITestResult result) {
		ExtentTestManager.getTest().assignCategory(getSimpleClassName(result));
		addExtentLabelToTest(result);
		ExtentTestManager.endTest();
	}

	private  synchronized String takeScreenshot(String methodName, WebDriver driver) {
		DateFormat dateFormat = new SimpleDateFormat("MMM_dd_yyyy_HH_mm_ss_SSS");
		Date date = new Date();
		String dateName = dateFormat.format(date);
		String filePathExtent = OUTPUT_FOLDER_SCREENSHOTS + "Web" + methodName + "_" + dateName + ".png";
		String filePath = ExtentManager.getReportBaseDirectory() + filePathExtent;
		String encodedBase64 = null;
		FileInputStream fileInputStreamReader = null;
		try {
			File screenshotFile = ((TakesScreenshot)  driver).getScreenshotAs(OutputType.FILE);			
			fileInputStreamReader = new FileInputStream(screenshotFile);
			byte[] bytes = new byte[(int) screenshotFile.length()];
			int totalBytes = fileInputStreamReader.read(bytes);
			System.out.println(totalBytes);
			encodedBase64 = Base64.encodeBase64String(bytes);
			FileUtils.copyFile(screenshotFile, new File(filePath));
		} catch (IOException e) {
			e.getStackTrace();
			Reporter.log("Failed To Take screenshot " + e, true);
		}
		
		finally {
			
		try {
			if(fileInputStreamReader!= null)
			fileInputStreamReader.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		return encodedBase64;
	}

	@Override
	public synchronized void onTestFailure(ITestResult result) {
		ExtentTestManager.getTest().assignCategory(getSimpleClassName(result));
WebDriver driver = null;
try {
	driver = (WebDriver)result.getTestClass().getRealClass().getDeclaredField("driver").get(result.getInstance());
} catch (IllegalArgumentException | IllegalAccessException | NoSuchFieldException | SecurityException e1) {
	System.out.println("driver field doesn't exist");
	e1.printStackTrace();
}
		ExtentTestManager.getTest().log(Status.FAIL, result.getName() + " Test is failed" + result.getThrowable());
		try {
			ExtentTestManager.getTest().fail("<br><font color= red>" + "Screenshot of Web" + "</font></b>",
					MediaEntityBuilder.createScreenCaptureFromBase64String(takeScreenshot(getSimpleMethodName(result),driver))
							.build());
		} catch (IOException e) {
			e.printStackTrace();
		}
		addExtentLabelToTest(result);
		ExtentTestManager.endTest();
	}

	@Override
	public synchronized void onTestSkipped(ITestResult result) {
		ExtentTestManager.getTest().log(Status.SKIP, result.getName() + " Test is Skipped" + result.getThrowable());
	}

	@Override
	public synchronized void onTestFailedButWithinSuccessPercentage(ITestResult result) {
	}

	private synchronized String getSimpleClassName(ITestResult result) {
		return result.getMethod().getRealClass().getSimpleName();
	}

	private synchronized String getSimpleMethodName(ITestResult result) {
		return result.getName();
	}

	private synchronized void addExtentLabelToTest(ITestResult result) {
		if (result.getStatus() == ITestResult.SUCCESS)
			ExtentTestManager.getTest().pass(MarkupHelper.createLabel("Test Passed", ExtentColor.GREEN));
		else if (result.getStatus() == ITestResult.FAILURE) {
			ExtentTestManager.getTest().fail(MarkupHelper.createLabel("Test Failed", ExtentColor.RED));
		} else
			ExtentTestManager.getTest().skip(MarkupHelper.createLabel("Test Skipped", ExtentColor.ORANGE));
	}
}