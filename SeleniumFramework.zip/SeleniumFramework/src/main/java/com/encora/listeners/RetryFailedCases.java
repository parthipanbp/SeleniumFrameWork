package com.encora.listeners;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

public class RetryFailedCases implements IRetryAnalyzer {
	
	private int retryCount = 0;
	  private static final int maxRetryCount = 2;
	 
	  @Override
	  public boolean retry(ITestResult iTestresult) {
		  //if (result.isSuccess()) { 
	    if (retryCount < maxRetryCount) {
	    	System.out.println("Retrying " + iTestresult.getName() + " again and the count is " + (retryCount+1));
	    	retryCount++;
	    	
	    	//iTestResult.setStatus(ITestResult.FAILURE);  //Mark test as failed
            return true;                                 //Tells TestNG to re-run the test
        } //else {
           // iTestResult.setStatus(ITestResult.FAILURE);  //If maxCount reached,test marked as failed
        //}
    //} else {
      //  iTestResult.setStatus(ITestResult.SUCCESS);      //If test passes, TestNG marks it as passed
    //}
    return false;
}
}
