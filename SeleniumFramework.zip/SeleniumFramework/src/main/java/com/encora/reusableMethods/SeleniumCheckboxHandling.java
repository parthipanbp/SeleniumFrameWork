package com.encora.reusableMethods;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


public class SeleniumCheckboxHandling extends WebPageOperations {

	public SeleniumCheckboxHandling(WebDriver driver) {
		super(driver);
	}

	/**
	 * This method is for selecting a checkbox
	 * 
	 * @param element is WebElement
	 *                  reference
	 */
	public static void selectTheCheckbox(WebElement element) {
		try {
			if (element.isSelected()) {
				System.out.println("Checkbox: " + element + "is already selected");
			} else {

				// Select the checkbox
				element.click();
			}
		} catch (Exception e) {
			System.out.println("Unable to select the checkbox: " + element);
		}

	}

	/**
	 * This method is for Deselecting a checkbox
	 * 
	 * @param element is WebElement reference
	 */
	public static void deSelect_The_Checkbox(WebElement element) {
		try {
			if (element.isSelected()) {
				// De-select the checkbox
				element.click();
			} else {
				System.out.println("Checkbox: " + element + "is already deselected");
			}
		} catch (Exception e) {
			System.out.println("Unable to deselect checkbox: " + element);
		}
	}

	/**
	 * This method is for selecting a checkbox
	 * 
	 * @param element is List<WebElement> reference which contains list of all
	 *                dropdown values valueToSelect is a unique field which use want
	 *                to tick
	 */
	public static void selectTheCheckBoxFromList(List<WebElement> element, String valueToSelect) {
		for (WebElement option : element) {
			System.out.println("Option value " + option.getText());
			if (valueToSelect.equalsIgnoreCase(option.getText())) {
				option.click();
				break;
			}

		}
	}

}
