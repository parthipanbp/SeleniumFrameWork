package com.encora.reusableMethods;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.time.Duration;
import java.util.Iterator;
import java.util.List;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import java.net.MalformedURLException;
import java.net.URL;

public class WebPageValidations extends WebPageOperations {

	/**
	 * Constructor to use webdriver object
	 */
	public WebPageValidations(WebDriver driver) {
		super(driver);

	}

	/**
	 * This method is to check if element is displayed on webpage
	 * 
	 * @param element is WebElement reference
	 */
	public  boolean elementIsDisplayed(WebElement element, String elementName) {
		boolean elementDisplaycheckresult;
		try {
			
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(waitTimeInSeconds));
			wait.until(ExpectedConditions.refreshed(ExpectedConditions.visibilityOf(element)));
			element.isDisplayed();
			highlightElement(element);
			elementDisplaycheckresult = true;
		} catch (Exception e) {
			System.out.println("Fail to check isDisplayed : " + elementName);
			elementDisplaycheckresult = false;
		}
		return elementDisplaycheckresult;
	}
	/**
	 * This method is to check if element is displayed on webpage
	 * 
	 * @param element is WebElement reference
	 * @param waitTime is the time to wait for the element
	 */
	public  boolean elementIsDisplayed(WebElement element, int waitTime) {
		boolean elementDisplaycheckresult;
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(waitTime));
			wait.until(ExpectedConditions.refreshed(ExpectedConditions.visibilityOf(element)));
			element.isDisplayed();
			highlightElement(element);
			elementDisplaycheckresult = true;
		} catch (Exception e) {
			System.out.println("Fail to check isDisplayed : " + element);
			elementDisplaycheckresult = false;
		}
		return elementDisplaycheckresult;
	}
	
	public  boolean elementIsSelected(WebElement element) {
		boolean elementSelectedcheckresult;
		try {
			
			highlightElement(element);
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(waitTimeInSeconds));
			wait.until(ExpectedConditions.refreshed(ExpectedConditions.visibilityOf(element)));
			element.isSelected();
			elementSelectedcheckresult = true;
		} catch (Exception e) {
			System.out.println("Fail to check isSelected : " + element);
			elementSelectedcheckresult = false;
		}
		return elementSelectedcheckresult;
			
		}


	/**
	 * Overridden Method This method is for to check if element is displayed on
	 * webpage
	 * 
	 * @param element is WebElement reference
	 */
	public  boolean elementToBeVisible(WebElement element, int waitTimeInSeconds) {
		boolean elementVisibilityCheck = false;
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(waitTimeInSeconds));
			wait.until(ExpectedConditions.refreshed(ExpectedConditions.visibilityOf(element)));
			elementVisibilityCheck = true;
		} catch (Exception e) {
			System.out.println(element + " is not visible");
			elementVisibilityCheck = false;

		}
		return elementVisibilityCheck;
	}

	/**
	 * This method is to check if element is present
	 * 
	 * @param element is WebElement reference
	 */
	public  boolean isElementPresent(List<WebElement> element) {
		List<WebElement> arrElements = element;
		if (arrElements.size() > 0 && arrElements != null) {
			return true;
		} else
			System.out.println("Element not found");
		return false;
	}

	/**
	 * This method is to validate if a webelement is clickable
	 * 
	 * @param element   is a webelement reference
	 * @param fieldName is a userDefined name of the field
	 */
	public  boolean isElementClickable(WebElement element, String fieldName) {
		boolean clickabilityCheck = false;
		try {
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(waitTimeInSeconds));
			wait.until(ExpectedConditions.refreshed(ExpectedConditions.elementToBeClickable(element)));
			System.out.println(fieldName + " is clickable.");
			 clickabilityCheck = true;
		} catch (Exception e) {
			System.out.println(fieldName + " Element is not clickable");
			e.printStackTrace();
			clickabilityCheck = false;
		}
		
		return clickabilityCheck;

	}

	/**
	 * This method is to validate page title by comparing with expected result
	 * 
	 * @param ExpectedTitle is expected title - user text
	 * @param fieldName     is a userDefined name of the field
	 */
	public  void pageTitleVerification(String ExpectedTitle) {
		try {
			String ActualTitle = getActualPageTitle();
			Assert.assertEquals(ActualTitle, ExpectedTitle);
			System.out.println("PASS: " + ActualTitle + " title verified successfully");
		} catch (Exception e) {
			System.out.println("FAIL: To verify the pagetitle");
			System.out.println(e);
		}
	}

	/**
	 * This method is to check if the field is enabled
	 * 
	 * @param element   is WebElement reference
	 * @param fieldName is a userDefined name of the field
	 */
	public  boolean isEnabled(WebElement element, String elementName) {
		boolean flag;

		if (element.isEnabled()) {
			flag = true;
			System.out.println(elementName + " button is enabled");
		} else {
			System.out.println(elementName + "button is not enabled");
			flag = false;
		}

		return flag;

	}

	/**
	 * This method is to check if if particular field is disabled
	 * 
	 * @param element   is WebElement reference
	 * @param fieldName is a userDefined name of the field
	 */
	public  boolean isDisabled(WebElement element, String elementName) {
		boolean isDisabled;
		try {
			elementToBeVisible(element,elementName);
			String id = element.getAttribute("disabled");
			isDisabled = id.contains("disabled");
			if (isDisabled = true) {
				System.out.println(elementName + " button is disabled");
			}
		} catch (Exception e) {
			System.out.println("Fail to check isEnabled : " + element);
			System.out.println(elementName + " button is enabled");
			isDisabled = false;
		}
		return isDisabled;
	}

	/**
	 * This method is to check if password is masked based on attribute value
	 * 
	 * @param element   is WebElement reference
	 * @param fieldName is a userDefined name of the field
	 */
	public  WebElement isPasswordMasked(WebElement element, String fieldName) {
		try {
			elementToBeVisible(element,fieldName);
			if (element.getAttribute("type").equalsIgnoreCase("password")) {
				System.out.println("PASS: " + fieldName + " is masked properly");
			} else {
				System.out.println("FAIL: " + fieldName + " is not masked");
			}
		} catch (Exception e) {
			System.out.println("FAIL: To check that is " + fieldName + " masked or not");
		}
		return element;
	}

	/**
	 * This method is to verify if page contains any broken links
	 * 
	 * @param links is list of web elements which represents links
	 */
	public  void testLinks(List<WebElement> links) {
		Iterator<WebElement> it = links.iterator();
		String url = "";
		int respCode = 200;
		while (it.hasNext()) {

			url = it.next().getAttribute("href");

			System.out.println(url);

			if (url == null || url.isEmpty()) {
				System.out.println("URL is either not configured for anchor tag or it is empty");
				continue;
			}
			getResponseCode(url);
			if (respCode >= 400) {
				System.out.println(url + " is a broken link");
			} else {
				System.out.println(url + " is a valid link");
			}
		}
	}

	/**
	 * This method is to get response code of a URL request
	 * 
	 * @param urlString is a URL whose response code to be retrieved
	 */
	public  int getResponseCode(String urlString) {
		int responseCode = 0;
		try {
			URL u = new URL(urlString);
			HttpURLConnection h = (HttpURLConnection) u.openConnection();
			h.setRequestMethod("HEAD");
			h.connect();
			responseCode = h.getResponseCode();
		} catch (MalformedURLException e) {

			e.printStackTrace();
			System.out.println("Failed to get Response code " + e.getMessage());

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return responseCode;
	}

}
