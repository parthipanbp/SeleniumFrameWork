package com.encora.reusableMethods;


import org.apache.commons.lang3.RandomStringUtils;

public class GenerateRandomTestData {

	/**
	 * This method is to generate random alpha numeric string of given length
	 * 
	 * @param length is the length of the random string to be generated
	 */
	public static String generateRandomAlphanumeric(int length) {
		String generatedString = RandomStringUtils.randomAlphanumeric(length);

		return generatedString;
	}

	/**
	 * This method is to generate random alphabetic number of given length
	 * 
	 * @param length is the length of the random string to be generated
	 */
	public static String generateRandomAlphabetic(int length) {
		String generatedString = RandomStringUtils.randomAlphabetic(length);

		return generatedString;
	}

	/**
	 * This method is to generate random alphabetic number of given length
	 * 
	 * @param length is the length of the random string to be generated
	 */
	public static String generateRandomNumeric(int length) {
		String generatedString = RandomStringUtils.randomNumeric(length);

		return generatedString;
	}
	
	

}
