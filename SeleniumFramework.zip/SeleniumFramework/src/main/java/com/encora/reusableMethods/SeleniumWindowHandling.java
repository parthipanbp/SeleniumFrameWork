package com.encora.reusableMethods;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.WebDriver;

public class SeleniumWindowHandling extends WebPageOperations {
	
	public SeleniumWindowHandling(WebDriver driver) {
		super(driver);
	}
	
	
	
	public  String switchToWindowAndGetTitle() {
		String pageTitle = null;
		String parentWindow =  driver.getWindowHandle();
		Set<String> childWindows = driver.getWindowHandles();
		
		Iterator<String> iterator = childWindows.iterator();
		while(iterator.hasNext()) {
			
			String childWindow =  iterator.next();
			if(!parentWindow.equals(childWindow)) {
				driver.switchTo().window(childWindow);
				 pageTitle = driver.switchTo().window(childWindow).getTitle();
				System.out.println();
				driver.close();
				
			}
		}
		driver.switchTo().window(parentWindow);
		return pageTitle;
		
	}
	

}
