package com.encora.reusableMethods;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class SeleniumDropdownHandling extends WebPageOperations {

	/**
	 * Constructor to use webdriver object
	 */
	public SeleniumDropdownHandling(WebDriver driver) {

		super(driver);

	}

	/**
	 * This method is for simple dropdown selection by visibleText
	 * 
	 * @param elementName      is field name which is user defined
	 * @param locator-This     is the unique attribute to find an dropdownelement
	 * @param visibleText-This is the text which is to be selected as dropdown value
	 * @throws Exception 
	 */
	public  void dropDownSelectionByText(WebElement element, String visibleText, String fieldName) throws Exception {
		elementToBeVisible(element,fieldName);
		try {			
			Select dropdown = new Select(element);
			dropdown.selectByVisibleText(visibleText);
			System.out.println("PASS: Successfully selected " + visibleText + " from " + element + " dropdown");
		} catch (Exception e) {
			System.out.println(
					"FAIL: Not able to select " + visibleText + " from " + element + " dropdown" + e.getMessage());
		}
	}

	/**
	 * This method is for simple dropdown selection by visibleText
	 * 
	 * @param elementName  is field name which is user defined
	 * @param Element-This is the unique attribute to find an dropdownelement
	 * @param value-This   is the unique value of dropdown options
	 * @throws Exception 
	 */
	public  void dropDownSelectionByValue(WebElement element, String value,String fieldName)  {
		elementToBeVisible(element,fieldName);
		try {		
			Select dropdownElement = new Select(element);
			dropdownElement.selectByValue(value);
			System.out.println("PASS: Successfully selected " + value + " from " + fieldName + " dropdown");
		} catch (Exception e) {
			System.out.println("FAIL: Not able to select " + value + " from " + fieldName + " dropdown");
		}
	}

	/**
	 * This method is for simple dropdown selection by index
	 * 
	 * @param driver
	 * @param locator-This is the unique attribute to find an dropdownelement
	 * @param value-This   is the text to search in dropdown
	 * @throws Exception 
	 */
	public  void dropDownSelectionByIndex(WebElement element, int dropDownValueIndex,String fieldName)  {
		elementToBeVisible(element,fieldName);
		try {
			highlightElement(element);
			Select dropdownElement = new Select(element);
			dropdownElement.selectByIndex(dropDownValueIndex);
			System.out.println(
					"PASS: Successfully selected " + dropDownValueIndex + " Index value from " + element + " dropdown");
		} catch (Exception e) {
			System.out.println("FAIL: Not able to select " + dropDownValueIndex + " Index value from " + element
					+ " dropdown" + e.getMessage());
		}
	}

	/**
	 * 
	 * This method reads all the options from a select
	 * 
	 * @param driver      : webdriver object
	 * @param selectXpath xpath of the select element
	 * @throws Exception 
	 */
	public  void getDropdownOptions(WebElement element,String fieldName) throws Exception {
		elementToBeVisible(element,fieldName);
		try {
			Select dropdown = new Select(element);
			List<WebElement> listOptions = dropdown.getOptions();
			if (listOptions != null) {
				for (WebElement listOption : listOptions) {
					System.out.println("PASS : List of dropdown values : ");
					System.out.println(listOption.getText());
				}
			} else
				System.out.println(element + " does not contain any values");

		} catch (Exception e) {
			System.out.println("FAIL : Unable to fetch dropdown values from " + element + e.getMessage());
		}

	}
}
