package com.encora.pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.encora.reusableMethods.WebPageValidations;

public class CartPage extends WebPageValidations {
	
	public CartPage(WebDriver driver) {
		super(driver);

	}
	
	@FindBy(xpath = "//div[@class = 'cart_item']//descendant::div[@class = 'inventory_item_name']")
	private List<WebElement> cartAddedItemsNames;
	
	@FindBy(id = "continue-shopping")
	private WebElement continueShopping;
	
	
	
	
	public List<String> getCartAddedItemsNames() {
		List<String> cartAddedItemsNamesList = new ArrayList<String>();
		System.out.println("total products displayed in the cart "+ cartAddedItemsNames.size());
		for (int i = 0; i < cartAddedItemsNames.size(); i++) {
			highlightElement(cartAddedItemsNames.get(i));
			cartAddedItemsNamesList.add(cartAddedItemsNames.get(i).getText());
			waitForSeconds(1);
		}
		return cartAddedItemsNamesList;
	
	}
	
	public void clickOnContinueShopping() {
		highlightElement(continueShopping);
		click(continueShopping, "Continue Shopping button");
	}


}
