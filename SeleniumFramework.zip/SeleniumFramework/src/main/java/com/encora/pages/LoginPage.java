package com.encora.pages;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.encora.reusableMethods.WebPageValidations;


public class LoginPage extends WebPageValidations {

	public LoginPage(WebDriver driver) {
		super(driver);
	}
	
	
	@FindBy(className = "login_logo")
	private WebElement swaglabsHeading;
	
	@FindBy(className = "bot_column")
	private WebElement swagLabsImage;
	
	@FindBy(id = "user-name")
	private WebElement userNameField;
	
	@FindBy(name = "password")
	private WebElement passwordField;
	
	@FindBy(xpath = "//input[@value = 'Login']")
	private WebElement loginButton;
	
	@FindBy(id = "login_credentials")
	private WebElement userNames;
	
	@FindBy(className = "login_password")
	private WebElement passwords;
	
	
	
	
	
	public String getPageTitle() {
		
		return getActualPageTitle();		
	}
	
	public String getPageURL() {
		
		return getCurrentURL();
	}
		
	public boolean headingIsDisplayed(String fieldName) {
		
		return elementIsDisplayed(swaglabsHeading, fieldName);
	}
	
	public boolean botImageIsDisplayed(String fieldName ) {
		return elementIsDisplayed(swagLabsImage, fieldName);		
	}
	
	public void enterUserName(String userName, String fieldName) {
		enterTextintoField(userNameField, userName, fieldName);		
	}
	
	public void enterPassword(String password, String fieldName) {
		enterTextintoField(passwordField, password, fieldName);
	}
	
	public void clickOnLogin(String fieldName) {
		click(loginButton, fieldName);
	}
	
	public String getUserNames(String fieldName) {
		String defaultUserNames =  getText(userNames, fieldName);
		System.out.println(defaultUserNames);
		return defaultUserNames;
	}
	
	public String getPassword(String fieldName) {
		String defaultPassword =  getText(passwords, fieldName);
		System.out.println(defaultPassword);
		return defaultPassword;
	}
	
	public void login(String userName, String password) {
		enterUserName(userName, "user name field");
		enterPassword(password, "password field");
		clickOnLogin("login button");
		
	}
	
	


}
