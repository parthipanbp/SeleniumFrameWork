package com.encora.pages;


import java.util.ArrayList;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.encora.reusableMethods.SeleniumDropdownHandling;
import com.encora.reusableMethods.WebPageValidations;

public class InventoryPage extends WebPageValidations {

	public InventoryPage(WebDriver driver) {
		super(driver);

	}

	@FindBy(xpath = "//button[text() = 'Open Menu']")
	private WebElement menuIcon;
	
	@FindBy(className =  "shopping_cart_link")
	private WebElement shoppingCartLink;
	
	@FindBy(xpath = "//span[text()='Products']")
	private WebElement productsText;
	
	@FindBy(className = "peek")
	private WebElement robotIcon;
	
	@FindBy(className = "product_sort_container" )
	private WebElement productsSortFilter;
	
	@FindBy(xpath = "//div[@class = 'inventory_item']")
	private List<WebElement> itemsList;
	
	@FindBy(className = "shopping_cart_badge")
	private WebElement cartItemsCount;
	
	@FindBy(xpath = "//div[@class = 'inventory_item']//descendant::a[contains(@id, 'title_link')]")
	private List<WebElement> productsNames;
	
	@FindBy(xpath = "//*[text() = 'Logout']")
	private WebElement logoutLink;
	

	
	public String getPageURL() {
		
		return getCurrentURL();		
	}
	//you can pass fieldName either from test class or from page class
	public boolean menuIconIsDisplayed() {
		return elementIsDisplayed(menuIcon, "menu icon");
	}
	
	public boolean shoppingCartLinkIsDisplayed() {
		return elementIsDisplayed(shoppingCartLink, "shopping cart link");
	}
	
	public boolean productsHeadingIsDisplayed() {
		return elementIsDisplayed(productsText, "products heading");
	}
	
	public boolean robotIconIsDisplayed() {
		return elementIsDisplayed(robotIcon, "robot icon");
	}
	
	public void applyLowToHighFilter(String value) {
		click(productsSortFilter, "products sort filter");
		new SeleniumDropdownHandling(driver).dropDownSelectionByValue(productsSortFilter, value, "products sort filter");
		
	}
	
	public void addProductsToCart(WebDriver driver) {
		
		for (int i = 1; i <= itemsList.size(); i++) {
			WebElement addToCartButton = driver.findElement(By.xpath
					("//div[@class = 'inventory_item']["+i+"]//descendant::div[@class = 'pricebar']//button[text() = 'Add to cart']"));
			highlightElement(addToCartButton);
			click(addToCartButton, "Add to Cart Button");
			waitForSeconds(1);
			
		}
		
		
	}
	
	public int getTotalProductsCount() {	
		return itemsList.size();
		
	}
	
	public int getCartAddedItemsCount() {
		scrollDownToElement(cartItemsCount, "Cart Items count");
		 String text  = getText(cartItemsCount, "cart items count");
		int count = Integer.parseInt(text);
		System.out.println(count);
		return count;
		
	}
	
	public void clickOnShoppingCart() {
		click(shoppingCartLink, "cart");
	}
	
	public List<String> getProductsNames() {
		List<String> productNamesList = new ArrayList<String>();
		System.out.println("total products added to cart "+ productsNames.size());
		for (int i = 0; i < productsNames.size(); i++) {
			highlightElement(productsNames.get(i));
			productNamesList.add(productsNames.get(i).getText());
			//Collections.sort(productNamesList);
		}
		return productNamesList;
	
	}
	
	public void clickOnMenuIcon() {	
		click(menuIcon, "menu icon");
	}
	
	public void clickOnLogoutLink() {
		highlightElement(logoutLink);
		click(logoutLink, "logout link");
	}
	
	
	
	
	
	
	
	
	
	
}
