package com.encora.utilities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;


import io.github.bonigarcia.wdm.WebDriverManager;


public class DriverFactory {
	
	
	public WebDriver driver;
	
	
	public WebDriver getDriver() {
		return driver;
	}
	public WebDriver lauchBrowser() throws Exception {
		
		
		String browser = AppConfig.browser.toLowerCase();
		switch (browser) {
		case "chrome": {
			
			driver = WebDriverManager.chromedriver().create();
			System.out.println("ChromeDriver started Successfully");
			break;
		}
		
		case "firefox" : {
			
			driver = WebDriverManager.firefoxdriver().create();
			System.out.println("FireFox browser started successfully");
			break;
		}
		
		case "edge" : {
			
			driver = WebDriverManager.edgedriver().create();
			System.out.println("Edge browser loaded successfully");
			break;
		}
		
		case "chrome_incognito" : {
			
			 WebDriverManager.chromedriver().setup();
			 DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
			 //desiredCapabilities.se
			 ChromeOptions chromeOptions = new ChromeOptions();
			 chromeOptions.addArguments("incognito"); // ChromeOptions for starting chrome in incognito mode
			 desiredCapabilities.setCapability(ChromeOptions.CAPABILITY, chromeOptions);
				driver = new ChromeDriver(chromeOptions);
				System.out.println("ChromeDriver started Successfully in incognito mode");
				break;
			
		}
		
		
		default:
		throw new Exception("Unable to launch browser, browser variable has not passed or incorrect browser value has passed!");
		}
		return driver;
	}
}
