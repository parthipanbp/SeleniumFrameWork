package com.encora.utilities;
//package com.veracross.magnus.utilities;
//
//import java.io.IOException;
//import java.util.ArrayList;
//import java.util.Objects;
//import java.util.stream.Collectors;
//import java.util.stream.Stream;
//import java.util.List;
//import java.util.Objects;
//import java.util.stream.Collectors;
//import java.util.stream.Stream;
//
//import org.testng.annotations.DataProvider;
//import org.testng.annotations.Test;
//
//import jdk.jfr.DataAmount;
//
//public class ExcelTestClass {
//
//	ExcelUtility erw;
//	int totalRows;
//
//	public String path = System.getProperty("user.dir") + "\\src\\test" + "\\resources\\testData.xlsx";
//
//	@Test(dataProvider = "loginData")
//	public void TestMethod(String userType, String userName, String password) throws IOException {
////		Log.startTestCase("Starting Testcase");
////		Log.info("Starting Test");
//
//		System.out.println("userType is " + userType);
//		System.out.println("username is   " + userName);
//		System.out.println("password is   " + password);
//
//		System.out.println("completed");
//	}
//
//	@DataProvider(name = "loginData")
//	public String[][] getData() {
//		String[][] result = null;
//
//		String loginData[][] = null;
//		String[][] newLoginData = null;
//
//		erw = new ExcelUtility(path);
//		try {
//
//			// erw.setCellData("Test", "=COUNTIF(A2:A4, \"Student\")", 10, 3);
//
//			totalRows = erw.getTotalNumberOfRows("Test");
//			System.out.println(totalRows);
//			int totalColumns = erw.getTotalNumberOfColumns("Test", 1);
//			System.out.println(totalColumns);
//			loginData = new String[totalRows][totalColumns];
//
//			for (int i = 1; i <= totalRows; i++) // 1
//			{
//				if (erw.getCellData("Test", i, 0).equalsIgnoreCase("Student")) {
//					for (int j = 0; j < totalColumns; j++) // 0
//					{
//
//						loginData[i - 1][j] = erw.getCellData("Test", i, j);
//					}
//					// newLoginData = cloneArray(loginData);
//
//				}
//			}
//
//		} catch (Exception e) {
//			// TODO: handle exception
//		}
//		return loginData;
//	}
//}
