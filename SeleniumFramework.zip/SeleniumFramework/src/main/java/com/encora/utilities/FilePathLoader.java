package com.encora.utilities;

import java.io.File;
import java.io.IOException;
import java.net.URL;

public class FilePathLoader {
    /**
     * sets/Identifies the file path based on given fileName
     *
    // * @param fileName name of the file
     */
public static  void main(String args[])
{
    try {
        FilePathLoader filePathLoader = new FilePathLoader();
        File file =  filePathLoader.setFilePath("UploadFile.png");
        System.out.println("File path is  "+file);
    }
    catch (IOException e)
    {
        e.printStackTrace();
    }
}

    public File setFilePath(String fileName) throws IOException
    {
        ClassLoader classLoader = getClass().getClassLoader();
        URL resource = classLoader.getResource(fileName);
        System.out.println("resource" + resource);
        if (resource == null) {
            throw new IllegalArgumentException("file is not found!");
        }
        File file  = new File(resource.getFile());
        System.out.println(file);
        return file;
    }
}
