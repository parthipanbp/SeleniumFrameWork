package com.encora.utilities;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.*;
import java.util.Properties;

public class ConfigFileReader {

	private Properties properties;
	public static String env;

	/**
	 * ConfigFileReader constructor is used to load properties file
	 * 
	 * @param fileName is the name of the properties file
	 */

//	public ConfigFileReader(String fileName) {
//		BufferedReader reader;
//		String configFile;
//		  env = AppConfig.environment.toUpperCase();
//		try {
//			if (fileName.equalsIgnoreCase("configuration")) {
//				configFile = "./src/main/resources/" + fileName + ".properties";
//				System.out.println("Configuration file is loaded");
//			} else {
//				configFile = "./src/test/resources/configs/"+env+"/" + fileName + ".properties";
//				System.out.println(fileName + " loaded successfully");
//			}
//			reader = new BufferedReader(new FileReader(configFile));
//
//			properties = new Properties(System.getProperties());
//			try {
//				properties.load(reader);
//				reader.close();
//			} catch (IOException e) {
//				e.printStackTrace();
//			}
//		} catch (FileNotFoundException e) {
//			e.printStackTrace();
//			throw new RuntimeException("exception occurred during load prop file " + e);
//		}
//		System.setProperties(properties);
//	}
	
	public void loadPropertiesFile(String fileName) {
		BufferedReader reader;
		String configFile;
		  env = AppConfig.environment.toUpperCase();
		try {
			if (fileName.equalsIgnoreCase("configuration")) {
				configFile = "./src/main/resources/" + fileName + ".properties";
				System.out.println("Configuration file is loaded");
			} else {
				configFile = "./src/test/resources/configs/"+env+"/" + fileName + ".properties";
				System.out.println(fileName + " loaded successfully");
			}
			reader = new BufferedReader(new FileReader(configFile));

			properties = new Properties(System.getProperties());
			try {
				properties.load(reader);
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			throw new RuntimeException("exception occurred during load prop file " + e);
		}
		System.setProperties(properties);
	}
	
	public String findOSType() {
		 String[] osWord =  System.getProperty("os.name").split(" ");
		 return osWord[0];
		 
	}
	
	public String selectBrowser(String browser) throws Exception{
		String driverPath = null;
		String OS = findOSType();
		switch (browser) {

		case "chrome":
			if(OS.equalsIgnoreCase("Windows")) {
			driverPath = properties.getProperty("windows.chrome.driver.path");
			}
			else if(OS.equalsIgnoreCase("Mac")) {
				driverPath = properties.getProperty("mac.chrome.driver.path");
			}

			else {
				throw new RuntimeException("driverPath not specified in the Configuration.properties file.");
			}
			if (driverPath != null)
				return driverPath;

		case "IE":

			driverPath = properties.getProperty("ie.driver.path");
			if (driverPath != null)
				return driverPath;
			else
				throw new RuntimeException("driverPath not specified in the Configuration.properties file.");

		case "firefox":
			driverPath = properties.getProperty("firefox.driver.path");
			if (driverPath != null)
				return driverPath;
			else
				throw new RuntimeException("driverPath not specified in the Configuration.properties file.");

		case "Edge":
			driverPath = properties.getProperty("edge.driver.path");
			if (driverPath != null)
				return driverPath;
			else
				throw new RuntimeException("driverPath not specified in the Configuration.properties file.");

		default:

			throw new Exception("Driver exe path is not available");
		}
	}

	/**
	 * This method is used to fetch driver path from properties file
	 * 
	 * @param browser is a userText that will act as key in fetching driver path
	 *                from properties file. Ex: chrome, IE etc
	 */
	public String getDriverPath(String browser) throws Exception {
		return selectBrowser(browser);

	}

	/**
	 * This method will get int value which is used for implicit wait time
	 */
	public int getImplicitWait() {
		String implicitlyWait = properties.getProperty("implicitWait");
		if (implicitlyWait != null)
			return Integer.parseInt(implicitlyWait);
		else
			throw new RuntimeException("implicitWait not specified in the Configuration.properties file.");
	}
	/**
	 * This method will get int value which is used for implicit wait time
	 */
	public int getExplicitWait() {
		String explicitWait = properties.getProperty("explicitWait");
		if (explicitWait != null)
			return Integer.parseInt(explicitWait);
		else
			throw new RuntimeException("explicitWait not specified in the Configuration.properties file.");
	}
	
	public int getPageLoadWaitTime() {
		
		String pageLoadWaitTime = properties.getProperty("pageLoadWaitTime");
		if (pageLoadWaitTime != null)
			return Integer.parseInt(pageLoadWaitTime);
		else
			throw new RuntimeException("pageLoadWaitTime not specified in the Configuration.properties file.");
	}

	/**
	 * This method will get url value from properties file
	 */
	public String getApplicationUrl() {
		String url = properties.getProperty("url");
		if (url != null)
			return url;
		else
			throw new RuntimeException("url not specified in the Configuration.properties file.");
	}

}
