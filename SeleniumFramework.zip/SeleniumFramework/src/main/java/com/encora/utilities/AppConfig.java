package com.encora.utilities;

public class AppConfig {
	
	public static String browser = System.getProperty("browser", "chrome");
	public static String environment = System.getProperty("env", "qa");

}
