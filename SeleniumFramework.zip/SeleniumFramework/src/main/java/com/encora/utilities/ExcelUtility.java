package com.encora.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtility {
	private XSSFWorkbook excelWBook; // Excel WorkBook
	private XSSFSheet excelWorkSheet;
	//	private XSSFSheet excelWSheetByIndex;// Excel Sheet
	private XSSFCell cell; // Excel cell
	private XSSFRow row; // Excel row
	private  int rowNumber; // Row Number
	private  int columnNumber; // Column Number
	private  FileInputStream excelFile;
	private  CellStyle style;
	private  FileOutputStream fileOut;
	private File file;

	FilePathLoader filePathLoader;
	/**
	 *  Parameterized Constructor is used to read excel file based on given fileName and sheetName
	 *
	 * @param fileName name of the file
	 * @param sheetName name of the sheet from excel sheet
	 */
	public ExcelUtility(String fileName, String sheetName) {
		try {
			filePathLoader = new FilePathLoader();
			file = filePathLoader.setFilePath(fileName);
			excelFile = new FileInputStream(file);
			excelWBook = new XSSFWorkbook(excelFile);
			excelWorkSheet = excelWBook.getSheet(sheetName);
		} catch (IOException e) {

			e.printStackTrace();
		}

	}
	/**
	 *  Parameterized Constructor is used to read excel file based on given fileName
	 *
	 * @param fileName name of the file
	 * @param sheetNumber is the index of excelSheet. Indexing starts from 0
	 */
	public ExcelUtility(String fileName, int sheetNumber) {
		try {

			file = filePathLoader.setFilePath(fileName);
			excelFile = new FileInputStream(file);
			excelWBook = new XSSFWorkbook(excelFile);
			excelWorkSheet = excelWBook.getSheetAt(sheetNumber);
		} catch (IOException e) {

			e.printStackTrace();
		}


	}


	@SuppressWarnings("unused")
	private ExcelUtility() {

	}

	// This method reads the test data from the Excel cell.
	// We are passing  row number and column number as parameters.
	public String getCellData(int RowNum, int ColNum) {

		DataFormatter formatter = null;
		try {
			cell = excelWorkSheet.getRow(RowNum).getCell(ColNum);
			formatter = new DataFormatter();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return formatter.formatCellValue(cell);
	}

	// This method takes sheetName and row number as a parameter and returns the
	// data of given row number.
	public XSSFRow getRowData(String SheetName, int RowNum) {

		try {
			row = excelWorkSheet.getRow(RowNum);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return row;
	}

	// This method gets excel file, row and column number and set a value to the
	// that cell.
	public void setCellData(String sheetName, String value, int rowNum, int colNum) throws IOException {

		if (excelWBook.getSheetIndex(sheetName) == -1) // If sheet not exists then create new Sheet
			excelWBook.createSheet(sheetName);

		if (excelWorkSheet.getRow(rowNum) == null) // If row not exists then create new Row
			excelWorkSheet.createRow(rowNum);
		row = excelWorkSheet.getRow(rowNum);
		cell = row.getCell(colNum);
		if (cell == null) {
			cell = row.createCell(colNum);
			cell.setCellValue(value);
		} else {
			cell.setCellValue(value);
		}
		// Constant variables Test Data path and Test Data file name
		fileOut = new FileOutputStream(file);
		excelWBook.write(fileOut);
		fileOut.flush();
		fileOut.close();
	}

	/**
	 * This method will return the total number of rows inside excel sheet
	 *
	 * @param sheetName is the name of the excel sheet
	 * @return int contains the total number of rows value
	 */
	public int getTotalNumberOfRows(String sheetName) throws IOException

	{

		// int totalRows2 = getSheetByName(sheetName).getRowC
		int totalRows = excelWorkSheet.getLastRowNum();
//		workbook.close();
//		fi.close();
		return totalRows;
	}

	/**
	 * This method is will return the total number of columns inside excel sheet of
	 * a given row
	 *
	 * @param sheetName is the name of the excel sheet
	 * @param rowNumber is the row number from which data to be retrieved
	 * @return int contains total columns count
	 */
	public int getTotalNumberOfColumns(String sheetName, int rowNumber) throws IOException {
		int cellcount = getRowData(sheetName, rowNumber).getLastCellNum();
//		workbook.close();
//		fi.close();
		return cellcount;
	}

	/**
	 * This method will fill cell with given color
	 *
	 * @param sheetName is the name of the excel sheet
	 * @param rownum is the row number from which data to be retrieved
	 * @param colnum    is the column number
	 * @param color     is the color to be filled
	 * @return int contains total columns count
	 */
	public void fillGreenColor(String sheetName, int rownum, int colnum, String color) throws IOException {
//		fi=new FileInputStream(path);
//		workbook=new XSSFWorkbook(fi);
//		sheet=workbook.getSheet(sheetName);
//
		row = getRowData(sheetName, rownum);
		cell = row.getCell(colnum);
		style = excelWBook.createCellStyle();
		if (color.equalsIgnoreCase("green")) {
			style.setFillForegroundColor(IndexedColors.GREEN.getIndex());
			style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		} else if (color.equalsIgnoreCase("red")) {
			style.setFillForegroundColor(IndexedColors.RED.getIndex());
			style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		}

		else {

			System.out.println("Please enter either green or red as color");
		}

		cell.setCellStyle(style);
		excelWBook.write(fileOut);
		excelWBook.close();
		excelFile.close();
		fileOut.close();
	}

}